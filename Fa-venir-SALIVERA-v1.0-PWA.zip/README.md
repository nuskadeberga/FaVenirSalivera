# Fa venir SALIVERA · v1.0

Aplicació web personal preparada per publicar a GitHub Pages i instal·lar com a PWA.

## Fitxers que s’han de pujar

- `index.html`
- `style.css`
- `app.js`
- `data.js`
- `manifest.json`
- `service-worker.js`
- carpeta `assets/`

`README.md` i `MODEL-DE-DADES.md` són documentació i no són necessaris perquè la web funcioni.

## Actualitzar les dades

Les dades continuen centralitzades a `data.js`.
