# Fa venir SALIVERA · v0.7

Biblioteca personal de restaurants, receptes, vins, botigues i experiències, preparada per publicar-se a GitHub Pages.

## Novetats de la v0.7

- Estat d’activitat per a restaurants, botigues i experiències.
- Filtre per mostrar actius, tancats temporalment, tancats definitivament o tots.
- Avís visible a les fitxes dels establiments tancats.
- Categories múltiples per restaurant.
- Fotografia principal i galeria addicional.
- Valoració sobre 5 estrelles de menjar, servei, local i relació qualitat-preu.
- Camp «Hi tornaria?».
- Recomanacions i valoracions de diverses persones.
- Mitjanes automàtiques de les puntuacions disponibles.
- Registre opcional de visites, companyia, motiu i preu per persona.
- Relacions opcionals entre mòduls.
- Eliminat un bloc JavaScript antic que estava duplicat a la v0.6.

## Publicació a GitHub Pages

Puja `index.html`, `data.js`, `README.md` i `MODEL-DE-DADES.md` a l’arrel del repositori i activa GitHub Pages des de **Settings → Pages**.

Els camps nous encara no tenen dades reals: la interfície només els mostrarà quan s’incorporin a `data.js`.
